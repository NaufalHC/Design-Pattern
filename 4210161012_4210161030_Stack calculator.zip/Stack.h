#include <iostream>
#define MAX 10

using namespace std;

class Stack{
private :
	int arr[MAX];
	int top
	int number;
	int total;
public :
	virtual stack();
	virtual void Push();
	virtual void Pop();
	virtual void display();
};
