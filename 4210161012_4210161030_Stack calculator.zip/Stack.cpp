#include "Stack.h"
using namespace std;

void Stack::setStack(int _number, _top, _arr){
	number = _number;
	top = _top;
	arr = _arr;

void Stack::Push(int x){
	top++;
	if (top<MAX){
		arr[top]=x;
	}
	else{
		cout<<"STACK IS FULL!"<<endl;
		top--;
		return;
	}
}

void Stack::Pop(){
	if (top==-1){
		cout<<"STACK IS EMPTY!"<<endl;
		return 0;
	}
	else{
		int x=arr[top];
		arr[top]=0;
		top--;
		return x;
	}
}
