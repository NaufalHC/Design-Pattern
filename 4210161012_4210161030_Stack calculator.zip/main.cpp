#include<iostream>
#include "Stack.h"
#include "Calculator.h"
#include "Stack.cpp"
#include "Calculator.cpp"

using namespace std;

int main(){
	char _operation;
	char confirm;
	Stack Stack1;
	Calculator Calculator1;
	int number1, number2;
	do{
		cout <<"Begin ? Y/N";
		cin >> confirm;
		cout <<"Enter Operation : (+,-,/,*);
		cin >> _operation;
		switch (_operation){
			case '+':
				cout << "Input Number 1 : "; cin >> number1;
				cout << "Input Operator : "; cin >> _operation;
				cout << "Input Number 2 : "; cin >> number2;
				Calculator1.setOperation(_operation, number1, number2);
				
				break;
			case '-':
				
			case '/':
				myStack.clear();
				cout << "Input Operand 1 	: "; cin >> operand1;
				cout << "Input Operator(+, -) 	: "; cin >> _operator;
				cout << "Input Operand 2 	: "; cin >> operand2;
				myOperator.setOperator(_operator, operand1, operand2);
				myStack.setStack(perintah, myOperator.getResult());
				break;
			case '*':
				break;
		}
	}while(confirm != 'n||N');
	
	
	return 0;
}


