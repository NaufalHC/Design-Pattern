#include <iostream>
#include "Calculator.h"

using namespace std;

void operation::setOperation(char _operation,int _number1, int _number2){
	myOperation = _operation;
	number1 = _number1;
	number2 = _number2;
	switch(myOperation){
		case '+': 
			add();
			break;
		case '-':
			substract();
			break;
		case '*':
			multiplication();
			break;
		case '/':
			divide();
			break;
	}
	display();
}

void operation::add(){
	result = number1 + number2;
}
void operation::multiplication(	){
	
}
void operation::substract(){
	result = number1 - number2;
}
void operation::divide(){
	
}

void operation::display(){
	cout << "Result : "<< 
	result << endl;
}
int operation::getResult(){
	return result;
}
