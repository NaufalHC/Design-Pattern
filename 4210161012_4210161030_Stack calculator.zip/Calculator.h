#include <iostream>

using namespace std;

class Calculator{
private :
	char operation;
	int number1,number2, result;
public :
	virtual void setOperation(char _operation,int _number1,int _number2);
	virtual void add();
	virtual void multiplication();
	virtual void substract();
	virtual void divide();
	virtual void display();
	virtual int getResult();
};
