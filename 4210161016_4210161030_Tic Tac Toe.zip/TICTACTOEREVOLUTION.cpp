#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

void tampilkanPapan();
void giliranPemain();
int gameOver();
void mainLagi();
void gamePlay();
void tutorial();
void saveGame(int *scoreX, int *scoreO);
void resumeGame();
void loadGame(int *scoreX, int *scoreO);

	char papan[9] = {'1','2','3','4','5','6','7','8','9'};
	char giliran;
	int scoreX = 0;
	int scoreO = 0;
	int *scoreX_ = &scoreX;
	int *scoreO_ = &scoreO;
	int round = 0;
	bool draw = false;

int main (){
	loadGame(scoreX_,scoreO_);
	int mainmenu_;
	cout << "TICTACTOE REVOLUTION!\n";
	cout << "Pemain 1 [X] | Pemain 2 [O]\n";
	cout << "Perolehan Score:\nX = "<< *scoreX_ << "\nO = " << *scoreO_ << endl;
	cout << "Pilih Menu\n1. Mulai Baru\n2. Lanjutkan Permainan\n3. Cara Main\n4. Keluar\n\n";
	cin >> mainmenu_;
	switch (mainmenu_){
		case 1:
			scoreX = 0;
			scoreO = 0;
			gamePlay();
			break;
		case 2:
			resumeGame();
			break;
		case 3:
			tutorial();
			break;
		case 4:
			exit(0);
			break;
		default:
			cout<<"Error, bad input, quitting\n";
			break;
	}
	return 0;
}

void gamePlay(){
	giliran = 'X';
	while (!gameOver()){
		system("cls");
		tampilkanPapan();
		giliranPemain();
	}
	
	if (giliran == 'O' && !draw){
		scoreX += 1;
		system("cls");
		tampilkanPapan();
		cout << "\nPemain 1 [X] menang! Game Selesai!";
	}else if (giliran == 'X' && !draw){
		scoreO += 1;
		system("cls");
		tampilkanPapan();
		cout << "\nPemain 2 [O] menang! Game Selesai!";
	}else{
		system("cls");
		tampilkanPapan();
		cout << "\nGame seri! Game Selesai!";
	}
	mainLagi();
}

void tutorial(){
	char choice_;
	system("cls");
	cout << "Cara bermain Tic Tac Toe:"<<endl;
	cout << "1. Saat memulai permainan akan tampi papan yang memiliki nomor 1-9.\n2. Pilih nomor yang ingin diisi dengan tanda pemain."<<endl;
	cout << "3. Untuk memenangkan permainan, pemain harus meletakkan tanda yang sesuai milik player secara horizontal, vertikal, atau diagonal."<<endl;
	cout << "4. Pemain yang memenangkan permainan akan mendapatkan skor 1.";
	cout << "\n\nApakah Anda ingin kembali ke main menu?(Y/N)"<<endl;
	cin >> choice_;
	if (choice_ == 'Y'){
		system("cls");
		main();
	}else if(choice_ == 'N'){
		tutorial();
	}else{
		tutorial();
	}
}

void tampilkanPapan(){
	cout << "\nScore X = " << scoreX << " || Score O = " << scoreO << endl;
	cout << "\n-------------------------------------------------" << endl;
	cout << "		|		|	" << endl;
	cout << "	"<<papan[0]<<"	|	"<<papan[1]<<"	|	"<<papan[2]<<"	" << endl;
	cout << "________________|_______________|_______________" << endl;
	cout << "		|		|		" << endl;
	cout << "	"<<papan[3]<<"	|	"<<papan[4]<<"	|	"<<papan[5]<<"	" << endl;
	cout << "________________|_______________|_______________" << endl;
	cout << "		|		|		" << endl;
	cout << "	"<<papan[6]<<"	|	"<<papan[7]<<"	|	"<<papan[8]<<"	" << endl;
	cout << "		|		|		" << endl;	
	cout << "-------------------------------------------------" << endl;
}

void giliranPemain(){
	int pilihan;
	int sel = 0;
	
	if (giliran == 'X'){
		cout << "Sekarang giliran Pemain 1 [X]: ";
	}
	
	if (giliran == 'O'){
		cout << "Sekarang giliran Pemain 2 [O]: ";
	}
	
	cin >> pilihan;
	switch (pilihan){
		case 1: sel = 0; break;
		case 2: sel = 1; break;
		case 3: sel = 2; break;
		case 4: sel = 3; break;
		case 5: sel = 4; break;
		case 6: sel = 5; break;
		case 7: sel = 6; break;
		case 8: sel = 7; break;
		case 9: sel = 8; break;
		default:
			cout << "Angka yang Anda masukan salah! Coba lagi.\n";
			giliranPemain();
	}
	
	if (giliran == 'X' && papan[sel] != 'X'&& papan[sel] != 'O'){
		papan[sel] = 'X';
		giliran = 'O';
	}else if (giliran == 'O' && papan[sel] != 'O'&& papan[sel] != 'X'){
		papan[sel] = 'O';
		giliran = 'X';
	}else {
		cout << "Sel sudah terisi! Coba lagi.\n";
		giliranPemain();
	}
}

int gameOver(){
	
	if ((papan[0]==papan[1] && papan[1]==papan[2]) || (papan[3]==papan[4]&&papan[4]==papan[5]) || (papan[6]==papan[7]&&papan[7]==papan[8]) || 
	(papan[0]==papan[4]&&papan[4]==papan[8]) || (papan[2]==papan[4]&&papan[4]==papan[6])){
		return true;
	}
	
	if ((papan[0]==papan[3] && papan[3]==papan[6]) || (papan[1]==papan[4]&&papan[4]==papan[7]) || (papan[2]==papan[5]&&papan[5]==papan[8])){
		return true;
	}
	
	for (int i = 0; i < 9; i++){
		if (papan[i] != 'X' && papan[i] != 'O'){
				return false;
		}
	}
	draw = true;
	return true;
}

void mainLagi(){
	char main_;
	if (gameOver()){
		cout << "\nApakah Anda mau main lagi?(Y/N)";
		cin >> main_;
		if (main_ == 'Y'){
			system("cls");
			//char papan[9] = {'1','2','3','4','5','6','7','8','9'};
			papan[0] = '1';
			papan[1] = '2';
			papan[2] = '3';
			papan[3] = '4';
			papan[4] = '5';
			papan[5] = '6';
			papan[6] = '7';
			papan[7] = '8';
			papan[8] = '9';
			saveGame(scoreX_, scoreO_);
			gamePlay();
		}else if(main_ == 'N'){
			papan[0] = '1';
			papan[1] = '2';
			papan[2] = '3';
			papan[3] = '4';
			papan[4] = '5';
			papan[5] = '6';
			papan[6] = '7';
			papan[7] = '8';
			papan[8] = '9';
			saveGame(scoreX_, scoreO_);
			system("cls");
			main();
		}else{
		cout << "Pilihan salah!";
		mainLagi();
		}
		
	}
}

void saveGame(int *scoreX, int *scoreO){
	ofstream myfile ("savegame.txt");
  	if (myfile.is_open())
	  {
	    myfile << *scoreX <<endl;
		myfile << *scoreO <<endl;
		myfile.close();
	}
}

void resumeGame(){
	gamePlay();
}

void loadGame(int *scoreX, int *scoreO){
	ifstream loadgame("savegame.txt");
	int scoreX_;
	int scoreO_;
	if (loadgame.is_open()) {
		loadgame >> scoreX_ >> scoreO_;
		cout << scoreX_;
		cout << scoreO_;
		*scoreX = scoreX_;
		*scoreO = scoreO_;
		//loadgame >> scoreO_;
		//cout << scoreO_;
		loadgame.close();	
	}	
}

