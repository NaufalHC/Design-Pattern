#pragma once
#include "Order.h"
#include "Stock.h"
#include "BuyStock.h"
#include "SellStock.h"
#include "Broker.h"
#ifndef COMMANDPATTERN_H
#define COMMANDPATTERN_H
#include <vector>
#include <string>

using namespace std;
class CommandPatternDemo
{
   static void main(std::vector<std::wstring> &args);
};

#endif
